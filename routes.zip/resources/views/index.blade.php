@extends('templates.layout')
@section('breadcrumbs', 'Dashboard')

@section('content')
<h1>Hai</h1>
@endsection

